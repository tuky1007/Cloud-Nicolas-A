<!DOCTYPE html>
<html>
<head>
	<meta charset="iso-8859-1">
	<title>Graficas Telefonia Movil</title>
	<link rel="shortcut icon" href="images/logo.png"/>
</head>
<body>
	<img src="grafica_trafico.php" alt="Grafica 1" />
	<br><br>
	<img src="grafica_tecnologia.php" alt="Grafica 2" />
	<br><br>
	<img src="grafica_empresa.php" alt="Grafica 2" />
	<br><br>
</body>
</html>
