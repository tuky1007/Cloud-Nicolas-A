<?php
require("../../util/PHPlot/phplot.php");
require("../../object/dbase/dbase.php");

$year = date('Y');
$month = date('m');
$zona = "KENNEDY";

$datab = new DataB;
$datab->DB_connect();

$query = "select distinct DAY(rcfecha) dia from recibo, detrecibo 
			where rczona = drzona and rczona = '$zona' and YEAR(rcfecha) = $year and MONTH(rcfecha) = $month and 
				rcnumero = drrecibo
			order by DAY(rcfecha)";
$rslt = $datab->DB_Select($query);
$filas = $datab->DB_Numero_Filas($rslt);
$fildat = array();
while ($row = $datab->DB_Fetch_Array($rslt)) {
	$fildat[] = $row["dia"];
}
$datab->DB_Free_Result($rslt);

$query = "select distinct rcorigenpago origen from recibo, detrecibo 
			where rczona = drzona and rczona = '$zona' and YEAR(rcfecha) = $year and MONTH(rcfecha) = $month and 
				rcnumero = drrecibo 
			order by rcorigenpago";
$rslt = $datab->DB_Select($query);
$columnas = $datab->DB_Numero_Filas($rslt);
$coldat = array();
while ($row = $datab->DB_Fetch_Array($rslt)) {
	$coldat[] = $row["origen"];
}
$datab->DB_Free_Result($rslt);

$data = array();
for ($i = 0; $i < $filas; $i++) {
	$dia = $fildat[$i];
	
	$reg = array();
	$reg[] = $dia;
	for ($k = 0; $k < $columnas; $k++) {
		$origen = $coldat[$k];
		
		$query = "select sum(drvalor) valor from recibo, detrecibo 
			where rczona = drzona and rczona = '$zona' and YEAR(rcfecha) = $year and MONTH(rcfecha) = $month and 
				rcnumero = drrecibo and DAY(rcfecha) = $dia and rcorigenpago = '$origen'";
		$rslt = $datab->DB_Select($query);
		$rslt = $datab->DB_Select($query);
		list($valor) = $datab->DB_Fetch_Array($rslt);
		if (is_null($valor) || empty($valor)) $valor = 0;
		$datab->DB_Free_Result($rslt);
		
		$reg[] = $valor; 
	}
	$data[] = $reg;
}

/* Prueba 
print_r($data);
*/

$plot = new PHPlot(800, 200);
/*$plot->SetImageBorderType('plain');*/

/*$plot->SetPlotType('lines');
$plot->SetDataType('data-data');*/
$plot->SetDataValues($data);

# Main plot title:
$plot->SetTitle('Recaudo por Origenes de Pago');
$plot->SetXTitle('Dias');
$plot->SetYTitle('Recaudo');
$plot->SetLegend($coldat);


//Turn off X axis ticks and labels because they get in the way:
$plot->SetXTickLabelPos('none');
$plot->SetXTickPos('none');
		
$plot->DrawGraph();
?>